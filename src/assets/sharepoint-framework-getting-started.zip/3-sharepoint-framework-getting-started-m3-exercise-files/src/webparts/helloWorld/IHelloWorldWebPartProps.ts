export interface IHelloWorldWebPartProps {
  description: string;
  color: string;
}
