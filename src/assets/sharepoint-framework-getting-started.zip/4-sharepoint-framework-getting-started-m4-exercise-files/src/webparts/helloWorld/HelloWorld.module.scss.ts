/* tslint:disable */
require('./HelloWorld.module.css');
const styles = {
  helloWorld: 'helloWorld_6df9232b',
  container: 'container_6df9232b',
  row: 'row_6df9232b',
  listItem: 'listItem_6df9232b',
  button: 'button_6df9232b',
  label: 'label_6df9232b',
};

export default styles;
/* tslint:enable */