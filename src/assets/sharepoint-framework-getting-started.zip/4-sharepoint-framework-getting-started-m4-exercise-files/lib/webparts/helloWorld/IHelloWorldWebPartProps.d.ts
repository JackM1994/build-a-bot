export interface IHelloWorldWebPartProps {
    description: string;
}
