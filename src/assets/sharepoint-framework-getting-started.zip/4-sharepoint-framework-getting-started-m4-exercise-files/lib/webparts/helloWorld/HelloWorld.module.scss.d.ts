declare const styles: {
    helloWorld: string;
    container: string;
    row: string;
    listItem: string;
    button: string;
    label: string;
};
export default styles;
